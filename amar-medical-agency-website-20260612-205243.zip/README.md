# Amar Medical Agency Website

This is a static GitHub Pages-ready website generated from the merged Amar Medical Agency SEO master document.

## Publish on GitHub Pages

1. Create a new GitHub repository.
2. Upload all files from this folder to the repository root.
3. In GitHub, open Settings > Pages.
4. Set Source to "Deploy from a branch".
5. Choose the main branch and /root folder.
6. Save. GitHub will provide a https://USERNAME.github.io/REPOSITORY/ website URL.

For a user/organization domain like https://USERNAME.github.io/, name the repository exactly USERNAME.github.io.